<!-- File UUID: 4c7a2e91-6d3b-4f58-8a1e-b9f0d2c5e734 -->
# ai-file-manager (`afm`)

Keeps your Mac's Desktop and photo archives in order.

- **Taxonomy as data.** Folders and sorting rules live in one JSON file.
- **Sidecar indexes.** Each photo folder carries its own index and offline viewer in `0.afm/`, so it moves with the folder between drives and a NAS.
- **AI management.** Local CLIP search finds photos by what's in them. Nothing is uploaded.

## Install

```bash
brew install andrewhopper/tap/ai-file-manager
```

## Start

```bash
mkdir -p ~/.config/afm
cp "$(brew --prefix)/share/ai-file-manager/taxonomy.example.json" ~/.config/afm/taxonomy.json
afm --dry-run -v     # see what would move; nothing changes
afm                  # review the plan, press a to apply
```

Your rules live in `~/.config/afm/taxonomy.json` (or pass `--taxonomy <file>`).
Moves never overwrite, and every run can be previewed first.

## Index a photo folder

```bash
afm index ~/Pictures/2024            # thumbnails, EXIF, viewer → ~/Pictures/2024/0.afm/
afm index ~/Pictures/2024 --clip     # add AI search (downloads a ~150 MB model once)
afm search ~/Pictures/2024 "dog on a beach"
afm serve ~/Pictures/2024            # local viewer with tagging
```

`afm --help` lists every command.

More: https://blog.andrewhopper.com/projects/ai-file-manager · License: MIT
